from flask import Flask, request, send_file, render_template
from realesrgan import RealESRGAN
from PIL import Image
import os

app = Flask(__name__)

# Load model Real-ESRGAN
model = RealESRGAN('cpu')  # Ganti 'cuda' jika pakai GPU
model.load_weights('RealESRGAN_x4.pth')

UPLOAD_FOLDER = "static/uploads"
OUTPUT_IMAGE = "static/high_res.jpg"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return "No file uploaded", 400

    file = request.files['file']
    img_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(img_path)

    img = Image.open(img_path)
    sr_img = model.predict(img)
    sr_img.save(OUTPUT_IMAGE)

    return send_file(OUTPUT_IMAGE, mimetype='image/jpeg')

if __name__ == '__main__':
    app.run(debug=True)