from fastapi import FastAPI, UploadFile, File
from fastapi.responses import FileResponse
from realesrgan import RealESRGAN
from PIL import Image
import io, os

app = FastAPI()

# Load model Real-ESRGAN
model = RealESRGAN('cpu')  # Gunakan 'cuda' untuk GPU
model.load_weights('RealESRGAN_x4.pth')

UPLOAD_FOLDER = "static/uploads"
OUTPUT_IMAGE = "static/high_res.jpg"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.get("/")
def home():
    return {"message": "Welcome to Super-Resolution API!"}

@app.post("/upload/")
async def upload(file: UploadFile = File(...)):
    img = Image.open(io.BytesIO(await file.read()))
    sr_img = model.predict(img)
    sr_img.save(OUTPUT_IMAGE)
    
    return FileResponse(OUTPUT_IMAGE, media_type="image/jpeg")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)